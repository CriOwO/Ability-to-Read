Drag each folder in the Variants folder into the Starsector Mod folder, if they remain nested in this folder they will not appear as a new mod
